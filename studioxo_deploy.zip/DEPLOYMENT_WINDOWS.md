# Windows IIS Deployment Guide

This guide will help you deploy the Next.js application on your Windows VPS using IIS as a reverse proxy.

## 0. (Optional) Enable SSH for AI Assistance
If you want me (the AI) to do this for you, you must enable SSH on your server.
**Connect via RDP** one last time and run this in **PowerShell (Admin)**:

```powershell
# Install OpenSSH Server
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# Start the service
Start-Service sshd
Set-Service -Name sshd -StartupType 'Automatic'

# Open Firewall for Port 22
New-NetFirewallRule -Name sshd -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22

# (Optional) Set default shell to PowerShell
New-ItemProperty -Path "HKLM:\SOFTWARE\OpenSSH" -Name DefaultShell -Value "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -PropertyType String -Force
```

**After running this**:
1.  Tell me you are done.
2.  I will try to connect via `ssh administrator@162.55.212.193`.

---

## 1. Prerequisites (Done!)
I have already installed the following on your server via SSH:
- [x] **Node.js**: Installed.
- [x] **Git**: Installed.
- [x] **PM2**: Installed.
- [x] **IIS Web Server**: Installed.

## 2. Finish the Setup (Your Turn)
Since your repository is **Private**, I could not clone it automatically. You need to do this part manually.

1.  **Login** to your VPS via Remote Desktop.
2.  Open **PowerShell**.
3.  Go to the web folder:
    ```powershell
    cd C:\inetpub\wwwroot
    mkdir studioxo
    cd studioxo
    ```
4.  Clone your repo (Login when asked):
    ```powershell
    git clone -b pickpic-1 https://github.com/shazej/pickpic.git .
    ```
5.  Install and Build:
    ```powershell
    npm install
    npm run build
    pm2 start npm --name "studioxo" -- start
    pm2 save
    ```
6.  **Configure IIS Proxy**:
    - Open **IIS Manager**.
    - Click on your server -> **Application Request Routing Cache** -> Server Proxy Settings -> **Enable proxy**.
    - Create a new Site pointing to `C:\inetpub\wwwroot\studioxo`.
    - That's it! (The `web.config` file in the repo handles the rest).

## 4. Configure IIS
1.  Open **IIS Manager**.
2.  Right-click **Sites** -> **Add Website**.
    *   **Site name**: studioxo
    *   **Physical path**: `C:\inetpub\wwwroot\studioxo` (or wherever you put the files).
    *   **Port**: 80 (or your specific port).
3.  **IMPORTANT**: The `web.config` file I created in your project should technically exist in the physical path.
    *   This file tells IIS to forward all traffic to `http://localhost:3000`.

## 5. Verify
Open http://localhost (or your server IP) in the browser. You should see your Next.js app.
